/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package informationexpertmain;

import java.util.ArrayList;
import java.util.List;

// Class representing an item in the order
class Item {
    private String name;
    private double price;

    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}

// Class representing an order
class Order {
    private List<Item> items;

    public Order() {
        this.items = new ArrayList<>();
    }

    // Method to add an item to the order
    public void addItem(Item item) {
        items.add(item);
    }

    // Method to calculate the total price of the order
    public double calculateTotalPrice() {
        double total = 0.0;
        for (Item item : items) {
            total += item.getPrice();
        }
        return total;
    }

    // Method to display order details
    public void displayOrderDetails() {
        System.out.println("Order Details:");
        for (Item item : items) {
            System.out.println("- " + item.getName() + ": $" + item.getPrice());
        }
        System.out.printf("Total Price: $%.2f%n", calculateTotalPrice());
    }
}

// Main class to demonstrate the functionality
public class InformationExpertMain {
    public static void main(String[] args) {
        // Create an order
        Order order = new Order();

        // Add items to the order
        order.addItem(new Item("Laptop", 4900.99));
        order.addItem(new Item("Mouse", 250.50));
        order.addItem(new Item("Keyboard", 450.75));

        // Display order details
        order.displayOrderDetails();
    }
}
